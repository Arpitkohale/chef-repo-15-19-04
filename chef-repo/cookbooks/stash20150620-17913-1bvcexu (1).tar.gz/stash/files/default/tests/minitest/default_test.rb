require File.expand_path('../support/helpers', __FILE__)

describe_recipe 'stash::default' do
  include Helpers::Stash
end
